# Task Master AI - Claude Code Integration Guide

## Essential Commands

### Core Workflow Commands

```bash
# Project Setup
task-master init                                    # Initialize Task Master in current project
task-master parse-prd .taskmaster/docs/prd.txt      # Generate tasks from PRD document
task-master models --setup                        # Configure AI models interactively

# Daily Development Workflow
task-master list                                   # Show all tasks with status
task-master next                                   # Get next available task to work on
task-master show <id>                             # View detailed task information (e.g., task-master show 1.2)
task-master set-status --id=<id> --status=done    # Mark task complete

# Task Management
task-master add-task --prompt="description" --research        # Add new task with AI assistance
task-master expand --id=<id> --research --force              # Break task into subtasks
task-master update-task --id=<id> --prompt="changes"         # Update specific task
task-master update --from=<id> --prompt="changes"            # Update multiple tasks from ID onwards
task-master update-subtask --id=<id> --prompt="notes"        # Add implementation notes to subtask

# Analysis & Planning
task-master analyze-complexity --research          # Analyze task complexity
task-master complexity-report                      # View complexity analysis
task-master expand --all --research               # Expand all eligible tasks

# Dependencies & Organization
task-master add-dependency --id=<id> --depends-on=<id>       # Add task dependency
task-master move --from=<id> --to=<id>                       # Reorganize task hierarchy
task-master validate-dependencies                            # Check for dependency issues
task-master generate                                         # Update task markdown files (usually auto-called)
```

## Key Files & Project Structure

### Core Files

- `.taskmaster/tasks/tasks.json` - Main task data file (auto-managed)
- `.taskmaster/config.json` - AI model configuration (use `task-master models` to modify)
- `.taskmaster/docs/prd.txt` - Product Requirements Document for parsing
- `.taskmaster/tasks/*.txt` - Individual task files (auto-generated from tasks.json)
- `.env` - API keys for CLI usage

### Claude Code Integration Files

- `CLAUDE.md` - Auto-loaded context for Claude Code (this file)
- `.claude/settings.json` - Claude Code tool allowlist and preferences
- `.claude/commands/` - Custom slash commands for repeated workflows
- `.mcp.json` - MCP server configuration (project-specific)

### Directory Structure

```
project/
├── .taskmaster/
│   ├── tasks/              # Task files directory
│   │   ├── tasks.json      # Main task database
│   │   ├── task-1.md      # Individual task files
│   │   └── task-2.md
│   ├── docs/              # Documentation directory
│   │   ├── prd.txt        # Product requirements
│   ├── reports/           # Analysis reports directory
│   │   └── task-complexity-report.json
│   ├── templates/         # Template files
│   │   └── example_prd.txt  # Example PRD template
│   └── config.json        # AI models & settings
├── .claude/
│   ├── settings.json      # Claude Code configuration
│   └── commands/         # Custom slash commands
├── .env                  # API keys
├── .mcp.json            # MCP configuration
└── CLAUDE.md            # This file - auto-loaded by Claude Code
```

## MCP Integration

Task Master provides an MCP server that Claude Code can connect to. Configure in `.mcp.json`:

```json
{
  "mcpServers": {
    "task-master-ai": {
      "command": "npx",
      "args": ["-y", "--package=task-master-ai", "task-master-ai"],
      "env": {
        "ANTHROPIC_API_KEY": "your_key_here",
        "PERPLEXITY_API_KEY": "your_key_here",
        "OPENAI_API_KEY": "OPENAI_API_KEY_HERE",
        "GOOGLE_API_KEY": "GOOGLE_API_KEY_HERE",
        "XAI_API_KEY": "XAI_API_KEY_HERE",
        "OPENROUTER_API_KEY": "OPENROUTER_API_KEY_HERE",
        "MISTRAL_API_KEY": "MISTRAL_API_KEY_HERE",
        "AZURE_OPENAI_API_KEY": "AZURE_OPENAI_API_KEY_HERE",
        "OLLAMA_API_KEY": "OLLAMA_API_KEY_HERE"
      }
    }
  }
}
```

### Essential MCP Tools

```javascript
help; // = shows available taskmaster commands
// Project setup
initialize_project; // = task-master init
parse_prd; // = task-master parse-prd

// Daily workflow
get_tasks; // = task-master list
next_task; // = task-master next
get_task; // = task-master show <id>
set_task_status; // = task-master set-status

// Task management
add_task; // = task-master add-task
expand_task; // = task-master expand
update_task; // = task-master update-task
update_subtask; // = task-master update-subtask
update; // = task-master update

// Analysis
analyze_project_complexity; // = task-master analyze-complexity
complexity_report; // = task-master complexity-report
```

## Claude Code Workflow Integration

### Standard Development Workflow

#### 1. Project Initialization

```bash
# Initialize Task Master
task-master init

# Create or obtain PRD, then parse it
task-master parse-prd .taskmaster/docs/prd.txt

# Analyze complexity and expand tasks
task-master analyze-complexity --research
task-master expand --all --research
```

If tasks already exist, another PRD can be parsed (with new information only!) using parse-prd with --append flag. This will add the generated tasks to the existing list of tasks..

#### 2. Daily Development Loop

```bash
# Start each session
task-master next                           # Find next available task
task-master show <id>                     # Review task details

# During implementation, check in code context into the tasks and subtasks
task-master update-subtask --id=<id> --prompt="implementation notes..."

# Complete tasks
task-master set-status --id=<id> --status=done
```

#### 3. Multi-Claude Workflows

For complex projects, use multiple Claude Code sessions:

```bash
# Terminal 1: Main implementation
cd project && claude

# Terminal 2: Testing and validation
cd project-test-worktree && claude

# Terminal 3: Documentation updates
cd project-docs-worktree && claude
```

### Custom Slash Commands

Create `.claude/commands/taskmaster-next.md`:

```markdown
Find the next available Task Master task and show its details.

Steps:

1. Run `task-master next` to get the next task
2. If a task is available, run `task-master show <id>` for full details
3. Provide a summary of what needs to be implemented
4. Suggest the first implementation step
```

Create `.claude/commands/taskmaster-complete.md`:

```markdown
Complete a Task Master task: $ARGUMENTS

Steps:

1. Review the current task with `task-master show $ARGUMENTS`
2. Verify all implementation is complete
3. Run any tests related to this task
4. Mark as complete: `task-master set-status --id=$ARGUMENTS --status=done`
5. Show the next available task with `task-master next`
```

## Tool Allowlist Recommendations

Add to `.claude/settings.json`:

```json
{
  "allowedTools": [
    "Edit",
    "Bash(task-master *)",
    "Bash(git commit:*)",
    "Bash(git add:*)",
    "Bash(npm run *)",
    "mcp__task_master_ai__*"
  ]
}
```

## Configuration & Setup

### API Keys Required

At least **one** of these API keys must be configured:

- `ANTHROPIC_API_KEY` (Claude models) - **Recommended**
- `PERPLEXITY_API_KEY` (Research features) - **Highly recommended**
- `OPENAI_API_KEY` (GPT models)
- `GOOGLE_API_KEY` (Gemini models)
- `MISTRAL_API_KEY` (Mistral models)
- `OPENROUTER_API_KEY` (Multiple models)
- `XAI_API_KEY` (Grok models)

An API key is required for any provider used across any of the 3 roles defined in the `models` command.

### Model Configuration

```bash
# Interactive setup (recommended)
task-master models --setup

# Set specific models
task-master models --set-main claude-3-5-sonnet-20241022
task-master models --set-research perplexity-llama-3.1-sonar-large-128k-online
task-master models --set-fallback gpt-4o-mini
```

## Task Structure & IDs

### Task ID Format

- Main tasks: `1`, `2`, `3`, etc.
- Subtasks: `1.1`, `1.2`, `2.1`, etc.
- Sub-subtasks: `1.1.1`, `1.1.2`, etc.

### Task Status Values

- `pending` - Ready to work on
- `in-progress` - Currently being worked on
- `done` - Completed and verified
- `deferred` - Postponed
- `cancelled` - No longer needed
- `blocked` - Waiting on external factors

### Task Fields

```json
{
  "id": "1.2",
  "title": "Implement user authentication",
  "description": "Set up JWT-based auth system",
  "status": "pending",
  "priority": "high",
  "dependencies": ["1.1"],
  "details": "Use bcrypt for hashing, JWT for tokens...",
  "testStrategy": "Unit tests for auth functions, integration tests for login flow",
  "subtasks": []
}
```

## Claude Code Best Practices with Task Master

### Context Management

- Use `/clear` between different tasks to maintain focus
- This CLAUDE.md file is automatically loaded for context
- Use `task-master show <id>` to pull specific task context when needed

### Iterative Implementation

1. `task-master show <subtask-id>` - Understand requirements
2. Explore codebase and plan implementation
3. `task-master update-subtask --id=<id> --prompt="detailed plan"` - Log plan
4. `task-master set-status --id=<id> --status=in-progress` - Start work
5. Implement code following logged plan
6. `task-master update-subtask --id=<id> --prompt="what worked/didn't work"` - Log progress
7. `task-master set-status --id=<id> --status=done` - Complete task

### Complex Workflows with Checklists

For large migrations or multi-step processes:

1. Create a markdown PRD file describing the new changes: `touch task-migration-checklist.md` (prds can be .txt or .md)
2. Use Taskmaster to parse the new prd with `task-master parse-prd --append` (also available in MCP)
3. Use Taskmaster to expand the newly generated tasks into subtasks. Consdier using `analyze-complexity` with the correct --to and --from IDs (the new ids) to identify the ideal subtask amounts for each task. Then expand them.
4. Work through items systematically, checking them off as completed
5. Use `task-master update-subtask` to log progress on each task/subtask and/or updating/researching them before/during implementation if getting stuck

### Git Integration

Task Master works well with `gh` CLI:

```bash
# Create PR for completed task
gh pr create --title "Complete task 1.2: User authentication" --body "Implements JWT auth system as specified in task 1.2"

# Reference task in commits
git commit -m "feat: implement JWT auth (task 1.2)"
```

### Parallel Development with Git Worktrees

```bash
# Create worktrees for parallel task development
git worktree add ../project-auth feature/auth-system
git worktree add ../project-api feature/api-refactor

# Run Claude Code in each worktree
cd ../project-auth && claude    # Terminal 1: Auth work
cd ../project-api && claude     # Terminal 2: API work
```

## Troubleshooting

### AI Commands Failing

```bash
# Check API keys are configured
cat .env                           # For CLI usage

# Verify model configuration
task-master models

# Test with different model
task-master models --set-fallback gpt-4o-mini
```

### MCP Connection Issues

- Check `.mcp.json` configuration
- Verify Node.js installation
- Use `--mcp-debug` flag when starting Claude Code
- Use CLI as fallback if MCP unavailable

### Task File Sync Issues

```bash
# Regenerate task files from tasks.json
task-master generate

# Fix dependency issues
task-master fix-dependencies
```

DO NOT RE-INITIALIZE. That will not do anything beyond re-adding the same Taskmaster core files.

## Important Notes

### AI-Powered Operations

These commands make AI calls and may take up to a minute:

- `parse_prd` / `task-master parse-prd`
- `analyze_project_complexity` / `task-master analyze-complexity`
- `expand_task` / `task-master expand`
- `expand_all` / `task-master expand --all`
- `add_task` / `task-master add-task`
- `update` / `task-master update`
- `update_task` / `task-master update-task`
- `update_subtask` / `task-master update-subtask`

### File Management

- Never manually edit `tasks.json` - use commands instead
- Never manually edit `.taskmaster/config.json` - use `task-master models`
- Task markdown files in `tasks/` are auto-generated
- Run `task-master generate` after manual changes to tasks.json

### Claude Code Session Management

- Use `/clear` frequently to maintain focused context
- Create custom slash commands for repeated Task Master workflows
- Configure tool allowlist to streamline permissions
- Use headless mode for automation: `claude -p "task-master next"`

### Multi-Task Updates

- Use `update --from=<id>` to update multiple future tasks
- Use `update-task --id=<id>` for single task updates
- Use `update-subtask --id=<id>` for implementation logging

### Research Mode

- Add `--research` flag for research-based AI enhancement
- Requires a research model API key like Perplexity (`PERPLEXITY_API_KEY`) in environment
- Provides more informed task creation and updates
- Recommended for complex technical tasks

---

# ComfyUI Web Interface - Complete Codebase Understanding

## Project Overview

This is a comprehensive web-based interface for ComfyUI, a powerful AI image generation tool. The application provides a modern, dark-themed interface that mimics Stable Diffusion WebUI conventions while offering enhanced functionality for workflow management, real-time progress tracking, and preset management.

## Core Architecture

### Frontend Stack
- **Pure HTML/CSS/JavaScript** - No frameworks, optimized for performance
- **Dark Theme Design System** - Professional UI with consistent color scheme
- **Responsive Layout** - Mobile-first design with breakpoints
- **Real-time Updates** - WebSocket integration for live generation feedback

### Backend Integration
- **ComfyUI API** - REST API for workflow submission and management
- **WebSocket Connection** - Real-time progress and status updates
- **LocalStorage** - Client-side persistence for presets and settings

## File Structure & Key Components

### Core Files
```
├── index.html              # Main application HTML structure
├── script.js               # Primary JavaScript application logic
├── style.css               # Complete styling and theme system
├── presetManager.js        # Workflow preset management system
└── CLAUDE.md              # This documentation file
```

### Configuration Files
```
├── .taskmaster/           # Task management system
├── .claude/               # Claude Code integration
├── .mcp.json             # MCP server configuration
└── .env                  # API keys and environment variables
```

## Application Components

### 1. Navigation System (`index.html:17-24`)
- **Tab-based Navigation**: txt2img, img2img, Extras, Settings, Queue
- **Active State Management**: Visual feedback for current mode
- **Accessibility**: ARIA labels and keyboard navigation

### 2. Generation Controls (`index.html:28-458`)
- **Workflow Upload**: Drag-and-drop JSON file handling
- **Parameter Controls**: Steps, CFG, dimensions, seed, batch size
- **Prompt Management**: Large textarea with improved UX
- **Generate/Cancel System**: State-managed buttons with loading states

### 3. API Connection Management (`index.html:98-131`)
- **Connection Testing**: Validates ComfyUI server availability
- **Apply Functionality**: Saves endpoint without testing
- **Status Indicators**: Visual feedback for connection state
- **URL Validation**: IPv4, IPv6, hostname, and port validation

### 4. Real-time Progress System (`index.html:66-95`)
- **WebSocket Integration**: Live updates from ComfyUI
- **Progress Visualization**: Step-by-step progress tracking
- **Status Display**: Current node execution and percentage
- **Cancellation Support**: Interrupt active generations

### 5. Preset Management System (`presetManager.js`)
- **Compression**: Base64 encoding for storage efficiency
- **Validation**: Comprehensive data integrity checks
- **Storage Management**: Quota monitoring and cleanup suggestions
- **Import/Export**: Backup and restore functionality

### 6. Metadata Display System (`script.js:2800-3200`)
- **Workflow Parsing**: Extracts parameters from ComfyUI JSON
- **Timing Analysis**: Generation duration and performance metrics
- **Parameter Display**: Organized, collapsible sections
- **History Integration**: Links with ComfyUI history API

## Key JavaScript Classes & Services

### 1. AppState Management (`script.js:150-300`)
```javascript
class AppState {
  constructor() {
    this.isGenerating = false;
    this.currentWorkflow = null;
    this.workflowMetadata = null;
    this.generationHistory = [];
    this.websocketService = null;
    this.interruptService = null;
  }
}
```

### 2. WebSocket Service (`script.js:400-800`)
- **Connection Management**: Auto-reconnection with exponential backoff
- **Event Handling**: Parsing ComfyUI WebSocket messages
- **Error Recovery**: Graceful handling of connection failures
- **Progress Tracking**: Real-time generation status updates

### 3. Interrupt Service (`script.js:1000-1200`)
- **Cancellation Logic**: Handles ComfyUI interrupt endpoint
- **State Management**: Prevents race conditions during cancellation
- **Error Handling**: Network failure recovery
- **Event Integration**: Coordinates with WebSocket events

### 4. Metadata Parser (`script.js:2800-3200`)
- **Workflow Analysis**: Extracts parameters from ComfyUI JSON
- **Multi-Architecture Support**: SD1.5, SDXL, Flux, SD3
- **Timing Calculation**: Performance metrics and duration formatting
- **Parameter Extraction**: Comprehensive metadata collection

### 5. Preset Storage Service (`presetManager.js:33-450`)
- **Compression System**: Efficient storage using base64 encoding
- **Data Validation**: Integrity checks and error handling
- **Storage Monitoring**: Quota tracking and cleanup suggestions
- **Backup System**: Import/export functionality

## CSS Design System (`style.css`)

### Color Scheme
```css
:root {
  --color-bg-primary: #0b0f19;      /* Main background */
  --color-bg-secondary: #181825;    /* Panel backgrounds */
  --color-bg-tertiary: #1f2937;     /* Input backgrounds */
  --color-accent-orange: #ff7c00;   /* Primary accent */
  --color-accent-blue: #1f77b4;     /* Secondary accent */
  --color-text-primary: #ffffff;    /* Primary text */
  --color-text-secondary: #9ca3af;  /* Secondary text */
  --color-border: #374151;          /* Borders and dividers */
  --color-error: #ef4444;           /* Error states */
  --color-success: #10b981;         /* Success states */
}
```

### Layout System
- **CSS Grid**: Used for metadata panel and complex layouts
- **Flexbox**: Primary layout system for components
- **Responsive Design**: Mobile-first with breakpoints at 480px, 768px, 1024px
- **Container Queries**: Future-ready responsive components

### Component Styling
- **Button States**: Hover, focus, disabled, loading animations
- **Form Controls**: Consistent styling across inputs, selects, textareas
- **Transitions**: Smooth animations with cubic-bezier timing
- **Shadows**: Layered depth system for visual hierarchy

## API Integration

### ComfyUI REST API
- **Workflow Submission**: POST to `/prompt` endpoint
- **Queue Management**: GET `/queue` for status monitoring
- **History Access**: GET `/history` for completed generations
- **Interruption**: POST `/interrupt` for cancellation

### WebSocket Protocol
- **Connection**: `ws://host:port/ws` for real-time updates
- **Message Types**: `executing`, `progress`, `executed`, `execution_error`
- **Event Handling**: Custom event system for UI updates
- **Reconnection**: Automatic reconnection with backoff

## Storage & Persistence

### LocalStorage Usage
- **Presets**: Compressed workflow storage with metadata
- **Settings**: API endpoints and user preferences
- **History**: Recent generation metadata
- **Configuration**: UI state and preferences

### Data Structures
```javascript
// Preset Structure
{
  id: "timestamp_random",
  name: "User-defined name",
  createdAt: "ISO timestamp",
  workflowData: { /* ComfyUI JSON */ },
  metadata: { /* extracted parameters */ }
}

// Metadata Structure
{
  generation: { steps, cfg, sampler, scheduler, seed },
  model: { name, architecture, hash },
  image: { width, height, batchSize },
  timing: { duration, startTime, endTime },
  prompts: { positive, negative }
}
```

## Performance Optimizations

### 1. Compression System
- **Base64 Encoding**: Fallback compression for preset storage
- **Data Validation**: Prevents corrupted data storage
- **Quota Management**: Monitors localStorage usage

### 2. Event Management
- **Debouncing**: Prevents excessive API calls
- **Throttling**: Limits WebSocket update frequency
- **Memory Management**: Proper cleanup of event listeners

### 3. UI Optimizations
- **Lazy Loading**: Deferred initialization of heavy components
- **Virtual Scrolling**: Efficient handling of large result sets
- **Animation Optimization**: GPU-accelerated transforms

## Error Handling & Recovery

### Network Errors
- **Timeout Handling**: Configurable request timeouts
- **Retry Logic**: Exponential backoff for failed requests
- **Fallback States**: Graceful degradation when offline

### Data Validation
- **Input Sanitization**: Prevents XSS and injection attacks
- **Type Checking**: Runtime validation of data structures
- **Error Boundaries**: Prevents complete application crashes

### User Feedback
- **Toast Notifications**: Non-intrusive error messages
- **Loading States**: Clear feedback during operations
- **Progress Indicators**: Visual feedback for long operations

## Recent Improvements & Bug Fixes

### 1. Connection Management Enhancement
- **Apply Button**: Save API endpoints without testing
- **URL Validation**: Comprehensive IPv4/IPv6/hostname validation
- **State Management**: Proper button state handling

### 2. Test Button Fix
- **DOM Structure**: Fixed null reference errors in status updates
- **Error Handling**: Improved connection test reliability
- **Browser Compatibility**: Cross-browser timeout handling

### 3. UI/UX Improvements
- **Prompt Box**: Removed fieldset borders, improved height/padding
- **Navigation**: Renamed tabs to match SD WebUI conventions
- **Responsive Design**: Enhanced mobile experience

### 4. Real-time Features
- **WebSocket Reliability**: Improved connection stability
- **Progress Tracking**: Enhanced step-by-step feedback
- **Cancellation System**: Proper interrupt handling

## Development Guidelines

### Code Style
- **Consistent Naming**: camelCase for variables, kebab-case for CSS
- **Modular Architecture**: Separate concerns into logical modules
- **Documentation**: Comprehensive inline comments
- **Error Handling**: Defensive programming practices

### Testing Strategy
- **Manual Testing**: Cross-browser compatibility testing
- **Integration Testing**: API endpoint validation
- **Performance Testing**: Load testing with large workflows
- **Accessibility Testing**: Screen reader and keyboard navigation

### Git Workflow
- **Feature Branches**: Separate branches for major features
- **Commit Messages**: Descriptive commit messages with context
- **Task Integration**: Link commits to task-master tasks
- **Code Review**: Pull request process for quality assurance

## Future Enhancements

### Planned Features
- **Advanced Samplers**: Dropdown selection for ComfyUI samplers
- **Workflow Editor**: Visual workflow creation and editing
- **Batch Processing**: Queue multiple generations
- **Cloud Integration**: Remote storage and sync

### Performance Improvements
- **Service Workers**: Offline functionality
- **Caching Strategy**: Intelligent asset caching
- **Code Splitting**: Lazy loading of feature modules
- **Bundle Optimization**: Minification and compression

### User Experience
- **Keyboard Shortcuts**: Power user functionality
- **Customizable UI**: Theme and layout preferences
- **Advanced Settings**: Expert mode configuration
- **Tutorial System**: Onboarding for new users

---

_This comprehensive documentation ensures Claude Code has complete understanding of the ComfyUI Web Interface codebase, enabling efficient development and maintenance of the application._

---

_This guide ensures Claude Code has immediate access to Task Master's essential functionality for agentic development workflows._
